package com.wipro.ElectricStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricStoreApplication.class, args);
	}

}
